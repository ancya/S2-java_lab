public class Sample_String{
  public static void main(String[] args){ 
  String str_Sample = "RockStar";
  System.out.println("Length of String: " + str_Sample.length());
  System.out.println("Character at position 5: " + str_Sample.charAt(5));
  System.out.println("EndsWith character 'r': " + str_Sample.endsWith("r"));
  System.out.println("Replace 'Rock' with 'Duke': " + str_Sample.replace("Rock", "Duke"));
}}
